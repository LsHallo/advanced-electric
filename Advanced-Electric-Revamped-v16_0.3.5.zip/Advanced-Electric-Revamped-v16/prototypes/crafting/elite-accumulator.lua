data:extend(
{
  {
    type = "recipe",
    name = "elite-accumulator",
    energy_required = 25,
    enabled = false,
    ingredients =
    {
      {"advanced-accumulator", 10},
      {"iron-plate", 45},
      {"battery", 25}
    },
    result = "elite-accumulator"
  }
}
)
