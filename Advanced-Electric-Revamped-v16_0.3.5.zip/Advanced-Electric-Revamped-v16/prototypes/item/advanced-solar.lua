data:extend(
{
  {
    type = "item",
    name = "advanced-solar",
    icon = "__Advanced-Electric-Revamped-v16__/graphics/icons/advanced-solar.png",
    icon_size = 32,
    subgroup = "energy",
    order = "d[solar-panel]-a[solar-panel]-b[solar-panel]",
    place_result = "advanced-solar",
    stack_size = 50
  }
}
)
